export LPORT=3000
export BIND_ADDR=0.0.0.0
export NPM_RUN_SCRIPT=start
export PROXY_PORT=8888
export NODE_ENV=production
export REDIS_HOST=172.88.88.2:6379
export REDIS_IP=172.88.88.2
export GATEWAY_HOST=172.88.88.1

export REDIS_PASSWORD=fakepassword
